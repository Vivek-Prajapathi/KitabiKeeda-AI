import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '../context/AuthContext';
import { ProtectedRoute } from '../components/ProtectedRoute';

// Layouts
import PublicLayout from '../layouts/PublicLayout';
import UserLayout from '../layouts/UserLayout';
import AdminLayout from '../layouts/AdminLayout';

// Public Pages
import Home from '../pages/Home';
import Courses from '../pages/Courses';
import CourseDetails from '../pages/CourseDetails';
import Login from '../pages/Login';
import Register from '../pages/Register';
import ActivateAccount from '../pages/ActivateAccount';

// User Pages
import Dashboard from '../pages/Dashboard';
import Profile from '../profile/Profile';
import MyLearning from '../profile/MyLearning';
import ProfileSettings from '../profile/ProfileSettings';

// Admin Pages
import AdminOverview from '../admin/pages/AdminOverview';
import AdminUsers from '../admin/pages/AdminUsers';
import AdminCourses from '../admin/pages/AdminCourses';
import AdminMarketplace from '../admin/pages/AdminMarketplace';
import AdminLMSAdmin from '../admin/pages/AdminLMSAdmin';
import AdminLayoutPage from '../admin/pages/AdminLayoutPage';
import AdminCoupons from '../admin/pages/AdminCoupons';
import AdminOrders from '../admin/pages/AdminOrders';
import AdminNotifications from '../admin/pages/AdminNotifications';
import AdminAnalytics from '../admin/pages/AdminAnalytics';

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<PublicLayout />}>
            <Route index element={<Home />} />
            <Route path="courses" element={<Courses />} />
            <Route path="courses/:id" element={<CourseDetails />} />
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="activate-account" element={<ActivateAccount />} />
          </Route>

          {/* User Routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <UserLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="profile" element={<Profile />} />
            <Route path="profile/my-learning" element={<MyLearning />} />
            <Route path="profile/settings" element={<ProfileSettings />} />
          </Route>

          {/* Admin Routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute requireAdmin>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<AdminOverview />} />
            <Route path="analytics" element={<AdminAnalytics />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="courses" element={<AdminCourses />} />
            <Route path="marketplace" element={<AdminMarketplace />} />
            <Route path="lms-admin" element={<AdminLMSAdmin />} />
            <Route path="coupons" element={<AdminCoupons />} />
            <Route path="orders" element={<AdminOrders />} />
            <Route path="notifications" element={<AdminNotifications />} />
            <Route path="layout" element={<AdminLayoutPage />} />
          </Route>

          {/* Catch all - 404 */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default AppRoutes;
