import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Award, Clock, Play } from 'lucide-react';
import { lmsAPI } from '../api/lms';

const MyLearning = () => {
  const [myLearning, setMyLearning] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMyLearning = async () => {
      try {
        const response = await lmsAPI.getMyLearning();
        if (response.data) {
          setMyLearning(response.data);
        }
      } catch (error) {
        console.error('Error fetching my learning:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMyLearning();
  }, []);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Learning</h1>
        <p className="text-gray-600">Track your enrolled courses and progress</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
              <div className="flex items-center space-x-4">
                <div className="h-20 w-20 bg-gray-200 rounded-lg"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : myLearning?.enrolledCourses?.length > 0 ? (
        <div className="space-y-4">
          {myLearning.enrolledCourses.map((enrollment) => (
            <Link
              key={enrollment._id}
              to={`/courses/${enrollment.courseId}`}
              className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow block"
            >
              <div className="flex items-start space-x-4">
                {enrollment.course?.thumbnail?.url ? (
                  <img
                    src={enrollment.course.thumbnail.url}
                    alt={enrollment.course.name}
                    className="h-20 w-20 object-cover rounded-lg"
                  />
                ) : (
                  <div className="h-20 w-20 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="h-10 w-10 text-indigo-400" />
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">{enrollment.course?.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                    {enrollment.course?.description}
                  </p>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <span className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{enrollment.progress || 0}% complete</span>
                    </span>
                    {enrollment.completed && (
                      <span className="flex items-center space-x-1 text-green-600">
                        <Award className="h-4 w-4" />
                        <span>Completed</span>
                      </span>
                    )}
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-indigo-600 h-2 rounded-full transition-all"
                      style={{ width: `${enrollment.progress || 0}%` }}
                    ></div>
                  </div>
                </div>
                <Play className="h-6 w-6 text-indigo-600 mt-4" />
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No enrolled courses</h3>
          <p className="text-gray-600 mb-6">Start your learning journey by enrolling in a course</p>
          <Link
            to="/courses"
            className="inline-flex items-center space-x-2 bg-indigo-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
          >
            <span>Explore Courses</span>
            <Play className="h-5 w-5" />
          </Link>
        </div>
      )}

      {/* Certificates Section */}
      {myLearning?.certificates && myLearning.certificates.length > 0 && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">My Certificates</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myLearning.certificates.map((certificate) => (
              <div key={certificate._id} className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Award className="h-8 w-8 text-yellow-500" />
                  <div>
                    <h3 className="font-semibold text-gray-900">{certificate.courseName}</h3>
                    <p className="text-sm text-gray-600">
                      Issued: {new Date(certificate.issuedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <button className="w-full bg-indigo-50 text-indigo-600 py-2 rounded-lg font-medium hover:bg-indigo-100 transition-colors">
                  Download Certificate
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MyLearning;
