import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Award, Clock, TrendingUp, Play, ArrowRight } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { lmsAPI } from '../api/lms';

const Dashboard = () => {
  const { user } = useAuth();
  const [myLearning, setMyLearning] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMyLearning = async () => {
      try {
        const response = await lmsAPI.getMyLearning();
        if (response.data?.success) {
          setMyLearning(response.data);
        }
      } catch (error) {
        console.error('Error fetching my learning:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMyLearning();
  }, []);

  return (
    <div>
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back, {user?.name || 'Learner'}!
        </h1>
        <p className="text-gray-600">Continue your learning journey</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <BookOpen className="h-8 w-8 text-indigo-600" />
            <span className="text-sm text-gray-500">Enrolled Courses</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {myLearning?.enrolledCourses?.length || 0}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <Award className="h-8 w-8 text-green-600" />
            <span className="text-sm text-gray-500">Certificates</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {myLearning?.certificates?.length || 0}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="h-8 w-8 text-purple-600" />
            <span className="text-sm text-gray-500">In Progress</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">
            {myLearning?.inProgress || 0}
          </p>
        </div>
      </div>

      {/* Continue Learning */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Continue Learning</h2>
          <Link
            to="/profile/my-learning"
            className="text-indigo-600 font-medium hover:text-indigo-700 inline-flex items-center space-x-1"
          >
            <span>View All</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center space-x-4 animate-pulse">
                <div className="h-16 w-16 bg-gray-200 rounded-lg"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : myLearning?.enrolledCourses?.length > 0 ? (
          <div className="space-y-4">
            {myLearning.enrolledCourses.slice(0, 3).map((enrollment) => (
              <Link
                key={enrollment._id}
                to={`/courses/${enrollment.courseId}`}
                className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
              >
                {enrollment.course?.thumbnail?.url ? (
                  <img
                    src={enrollment.course.thumbnail.url}
                    alt={enrollment.course.name}
                    className="h-16 w-16 object-cover rounded-lg"
                  />
                ) : (
                  <div className="h-16 w-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="h-8 w-8 text-indigo-400" />
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900 mb-1">{enrollment.course?.name}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{enrollment.progress || 0}% complete</span>
                    </span>
                  </div>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-indigo-600 h-2 rounded-full transition-all"
                      style={{ width: `${enrollment.progress || 0}%` }}
                    ></div>
                  </div>
                </div>
                <Play className="h-5 w-5 text-indigo-600" />
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No courses yet</h3>
            <p className="text-gray-600 mb-4">Start your learning journey by enrolling in a course</p>
            <Link
              to="/courses"
              className="inline-flex items-center space-x-2 bg-indigo-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
            >
              <span>Explore Courses</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link
          to="/courses"
          className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg p-6 text-white hover:from-indigo-600 hover:to-purple-700 transition-colors"
        >
          <div className="flex items-center space-x-4">
            <BookOpen className="h-10 w-10" />
            <div>
              <h3 className="font-semibold text-lg mb-1">Browse Courses</h3>
              <p className="text-indigo-100 text-sm">Discover new courses to learn</p>
            </div>
          </div>
        </Link>
        <Link
          to="/profile/settings"
          className="bg-gradient-to-br from-green-500 to-teal-600 rounded-lg p-6 text-white hover:from-green-600 hover:to-teal-700 transition-colors"
        >
          <div className="flex items-center space-x-4">
            <Award className="h-10 w-10" />
            <div>
              <h3 className="font-semibold text-lg mb-1">View Certificates</h3>
              <p className="text-green-100 text-sm">See your earned certificates</p>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Dashboard;
