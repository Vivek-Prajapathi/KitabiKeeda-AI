import { useEffect, useState } from 'react';
import { Users, BookOpen, ShoppingCart, TrendingUp, DollarSign } from 'lucide-react';
import { adminAPI } from '../../api/admin';
import { analyticsAPI } from '../../api/analytics';

const AdminOverview = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCourses: 0,
    totalOrders: 0,
    totalRevenue: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [usersRes, coursesRes, ordersRes] = await Promise.all([
          adminAPI.getAllUsers(),
          adminAPI.getAllCourses(),
          adminAPI.getAllOrders(),
        ]);

        if (usersRes.data.success) {
          setStats((prev) => ({ ...prev, totalUsers: usersRes.data.users?.length || 0 }));
        }
        if (coursesRes.data.success) {
          setStats((prev) => ({ ...prev, totalCourses: coursesRes.data.courses?.length || 0 }));
        }
        if (ordersRes.data.success) {
          setStats((prev) => ({ ...prev, totalOrders: ordersRes.data.orders?.length || 0 }));
        }
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      color: 'indigo',
    },
    {
      title: 'Total Courses',
      value: stats.totalCourses,
      icon: BookOpen,
      color: 'green',
    },
    {
      title: 'Total Orders',
      value: stats.totalOrders,
      icon: ShoppingCart,
      color: 'purple',
    },
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toFixed(2)}`,
      icon: DollarSign,
      color: 'yellow',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Overview</h1>
        <p className="text-gray-600">Dashboard overview and statistics</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded mb-4"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statCards.map((stat) => (
            <div key={stat.title} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <stat.icon
                  className={`h-8 w-8 ${
                    stat.color === 'indigo'
                      ? 'text-indigo-600'
                      : stat.color === 'green'
                      ? 'text-green-600'
                      : stat.color === 'purple'
                      ? 'text-purple-600'
                      : 'text-yellow-600'
                  }`}
                />
                <span className="text-sm text-gray-500">{stat.title}</span>
              </div>
              <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/admin/users"
            className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
          >
            <Users className="h-6 w-6 text-indigo-600 mb-2" />
            <h3 className="font-medium text-gray-900">Manage Users</h3>
            <p className="text-sm text-gray-600">View and manage user accounts</p>
          </a>
          <a
            href="/admin/courses"
            className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
          >
            <BookOpen className="h-6 w-6 text-indigo-600 mb-2" />
            <h3 className="font-medium text-gray-900">Manage Courses</h3>
            <p className="text-sm text-gray-600">Create and edit courses</p>
          </a>
          <a
            href="/admin/orders"
            className="p-4 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
          >
            <ShoppingCart className="h-6 w-6 text-indigo-600 mb-2" />
            <h3 className="font-medium text-gray-900">View Orders</h3>
            <p className="text-sm text-gray-600">Track and manage orders</p>
          </a>
        </div>
      </div>
    </div>
  );
};

export default AdminOverview;
